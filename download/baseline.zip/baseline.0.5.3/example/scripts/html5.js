document.createElement('header');
document.createElement('footer');
document.createElement('nav');
document.createElement('article');
document.createElement('section');
document.createElement('aside');